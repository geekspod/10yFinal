/* NT Addons for Elementor v1.0 */

!(function ($) {


    // Home Slider
    function homeSlider1($scope, $) {
        $scope.find('.promo-slider').each(function () {
            var promoSlider = $( this );
            var myData = promoSlider.data('slider-settings');
			if(!promoSlider.length) return;
			var status = $('.paging-info');
			promoSlider.on('init afterChange', function (event, slick, currentSlide, nextSlide) {
				var i = (currentSlide ? currentSlide : 0) + 1;
				status.text(i + '/' + slick.slideCount);
			});
			promoSlider.slick({
                autoplay: myData.autoplay,
				fade: myData.fade,
				adaptiveHeight: myData.adaptiveHeight,
				infinite: myData.infinite,
				speed: myData.speed,
				cssEase: 'ease-in-out',
				arrows: false,
				dots: myData.dots,
				appendDots: '.promo-dots',
			});
        });
    }
    // Home Slider
    function cooperationSlider($scope, $) {
        $scope.find('.cooperation-slider').each(function () {
            var cooperationSlider = $( this );
            var myData = cooperationSlider.data('slider-settings');
            if(!cooperationSlider.length) return;
            cooperationSlider.not('.slick-initialized').slick({
                arrows: false,
                slidesToShow:  myData.slidesToShow,
                adaptiveHeight:  myData.adaptiveHeight,
                autoplay:  myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
                responsive: [{
                    breakpoint: 1367,
                    settings: {
                        slidesToShow:  myData.slidesToShow1367,
                    }
                }, {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow:  myData.slidesToShow1200,
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow:  myData.slidesToShow992,
                    }
                }, {
                    breakpoint: 576,
                    settings: {
                        slidesToShow: 1,
                    }
                }]
            });
        });
    }
    // Testimonials Carousel
    function testiPrimary($scope, $) {
        $scope.find('.testimonials-primary-slider').each(function () {
            var $sliderPrimary = $( this );
            var myData = $sliderPrimary.data('slider-settings');
			if(!$sliderPrimary.length) return;
			$sliderPrimary.not('.slick-initialized').slick({
				arrows: false,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
				dots: myData.dots,
				appendDots: '.testimonials--primary .testimonials-dots',
			});
        });
        $scope.find('.testimonials-img-left-slider').each(function () {
            var $sliderLeft = $( this );
            var myData = $sliderLeft.data('slider-settings');
			if(!$sliderLeft.length) return;
			$sliderLeft.not('.slick-initialized').slick({
				arrows: false,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
				dots: myData.dots,
				appendDots: '.testimonials--img-left .testimonials-dots',
			});
        });
        $scope.find('.testimonials-img-right-slider').each(function () {
            var $sliderRight = $( this );
            var myData = $sliderRight.data('slider-settings');
			if(!$sliderRight.length) return;
			$sliderRight.not('.slick-initialized').slick({
				arrows: false,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
				dots: myData.dots,
				appendDots: '.testimonials--img-right .testimonials-dots',
			});
        });
    }

    // brandsSlider
    function brandsSlider($scope, $) {
        $scope.find('.brands-slider').each(function () {
            var $brandsSlider = $( this );
            var myData = $brandsSlider.data('slider-settings');
            console.log( typeof myData );
			if(!$brandsSlider.length) return;
			$brandsSlider.not('.slick-initialized').slick({
                slidesToShow: myData.slidesToShow,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
                dots: myData.dots,
				arrows: false,
				appendDots: '.brands-dots',
				responsive: [{
					breakpoint: 1200,
					settings: {
						slidesToShow: myData.slidesToShow1200,
						slidesToScroll: myData.slidesToScroll1200,
					}
				}, {
					breakpoint: 992,
					settings: {
						slidesToShow: myData.slidesToShow992,
						slidesToScroll: myData.slidesToScroll992,
					}
				}, {
					breakpoint: 768,
					settings: {
						slidesToShow: myData.slidesToShow768,
						slidesToScroll: myData.slidesToScroll768,
					}
				}]
			});
        });
    }
    // brandsSlider
    function brandsSliderTwo($scope, $) {
        $scope.find('.items-slider').each(function () {
            var $brandsSlider = $( this );
            var myData = $brandsSlider.data('slider-settings');
			if(!$brandsSlider.length) return;
			$brandsSlider.not('.slick-initialized').slick({
                slidesToShow: myData.slidesToShow,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
                dots: myData.dots,
				arrows: false,
				responsive: [{
					breakpoint: 1200,
					settings: {
						slidesToShow: myData.slidesToShow1200
					}
				}, {
					breakpoint: 768,
					settings: {
						slidesToShow: myData.slidesToShow768
					}
				}]
			});
        });
    }
    // casesSlider
    function casesSlider($scope, $) {
        $scope.find('.cases-slider').each(function () {
            var $casesSlider = $( this );
            var myData = $casesSlider.data('slider-settings');
			if(!$casesSlider.length) return;
			$casesSlider.not('.slick-initialized').slick({
                slidesToShow: myData.slidesToShow,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
                dots: myData.dots,
				arrows: false,
				appendDots: '.cases-dots',
				responsive: [{
					breakpoint: 1366,
					settings: {
						slidesToShow: myData.slidesToShow1366,
					}
				}, {
					breakpoint: 1200,
					settings: {
						slidesToShow: myData.slidesToShow1200,
					}
				}, {
					breakpoint: 768,
					settings: {
						slidesToShow: myData.slidesToShow768,
					}
				}]
			});
        });
    }
    // productsSlider
    function productsSlider($scope, $) {
        $scope.find('.products-slider').each(function () {
            var $productsSlider = $( this );
            var myData = $productsSlider.data('slider-settings');
			if(!$productsSlider.length) return;
			$productsSlider.not('.slick-initialized').slick({
                slidesToShow: myData.slidesToShow,
                slidesToScroll: myData.slidesToScroll,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
                dots: myData.dots,
				arrows: false,
				appendDots: '.products-slider-dots',
				responsive: [{
					breakpoint: 992,
					settings: {
						slidesToShow: myData.slidesToShow992,
						slidesToScroll: myData.slidesToScroll992,
					}
				}, {
					breakpoint: 768,
					settings: {
						slidesToShow: myData.slidesToShow768,
						slidesToScroll: myData.slidesToScroll768,
					}
				}, {
					breakpoint: 480,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1,
					}
				}]
			});
        });
    }
    // instagramSlider
    function instagramSlider($scope, $) {
        $scope.find('.instagram-slider').each(function () {
            var $instagramSlider = $( this );
            var myData = $instagramSlider.data('slider-settings');
			if(!$instagramSlider.length) return;
			$instagramSlider.not('.slick-initialized').slick({
                slidesToShow: myData.slidesToShow,
                slidesToScroll: myData.slidesToScroll,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite,
                dots: myData.dots,
				arrows: false,
				appendDots: '.instagram-dots',
				responsive: [{
                    breakpoint: 1600,
					settings: {
						slidesToShow: myData.slidesToShow1600,
						slidesToScroll: myData.slidesToScroll1600,
					}
				}, {
					breakpoint: 1366,
					settings: {
						slidesToShow: myData.slidesToShow1366,
						slidesToScroll: myData.slidesToScroll1366,
					}
				}, {
					breakpoint: 992,
					settings: {
						slidesToShow: myData.slidesToShow992,
						slidesToScroll: myData.slidesToScroll992,
					}
				}, {
					breakpoint: 768,
					settings: {
						slidesToShow: myData.slidesToShow768,
						slidesToScroll: myData.slidesToScroll768,
					}
				}, {
					breakpoint: 480,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1,
					}
				}]
			});
        });
    }
    // projectGallery
    function projectGallery($scope, $) {
        $scope.find('.project-gallery').each(function () {
            var $projectGallery = $( this );
            var myData = $projectGallery.data('slider-settings');
			if(!$projectGallery.length) return;
			$projectGallery.not('.slick-initialized').slick({
                slidesToShow: myData.slidesToShow, //6
                slidesToScroll: myData.slidesToScroll, //2,
                adaptiveHeight: myData.adaptiveHeight,
                autoplay: myData.autoplay,
                speed: myData.speed,
                infinite: myData.infinite, // false
                dots: myData.dots,
				arrows: false,
				appendDots: '.project-gallery-dots',
				responsive: [{
					breakpoint: 1600,
					settings: {
						slidesToShow: myData.slidesToShow1600,
						slidesToScroll: myData.slidesToScroll1600,
					}
				}, {
					breakpoint: 1366,
					settings: {
						slidesToShow: myData.slidesToShow1366,
						slidesToScroll: myData.slidesToScroll1366,
					}
				}, {
					breakpoint: 992,
					settings: {
						slidesToShow: myData.slidesToShow992,
						slidesToScroll: myData.slidesToScroll992,
					}
				}, {
					breakpoint: 768,
					settings: {
						slidesToShow: myData.slidesToShow768,
						slidesToScroll: myData.slidesToScroll768,
					}
				}, {
					breakpoint: 480,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1,
					}
				}]
			});
        });
    }
    // niceSelect
    function formFocusCorrection($scope, $) {
        $scope.find('.section-contact form label').each(function () {
            var $this = $( this );
            var $formDefault = $this.find('.form-field:not(select)');
        	if($formDefault.length){
        		$formDefault.focus(function(){
        			$(this).parents('form').addClass('focused');
        			$(this).parents('label').addClass('focused');
        		});
        		$formDefault.blur(function(){
        			var inputValue = $(this).val();
        			if (inputValue == ""){
                        $(this).parents('form').removeClass('focused');
        				$(this).parents('label').removeClass('focused');
        			} else {
                        $(this).parents('form').addClass('focused');
        				$(this).parents('label').addClass('focused');
        			};
        		});
        	};
        });
    }
    // detailTabs
    function detailTabs($scope, $) {
        $scope.find('.details-tabs').each(function () {
            var $detailTabs = $( this );
			if(!$detailTabs.length) return;
			$(".details-tabs .tabs-content__item").not(":first").hide();
			$(".details-tabs .tabs-header__title").on('click', function() {
				$(".details-tabs .tabs-header__title").removeClass("active").eq($(this).index()).addClass("active");
				$(".details-tabs .tabs-content__item").hide().eq($(this).index()).fadeIn(500)
			}).eq(0).addClass("active");
        });
    }

    // jarallaxElement
    function jarallaxElement($scope, $) {
        $scope.find('.jarallax').each(function () {
            var $this = $( this );

            if ($(window).width() > 1200) {
    			 $this.jarallax({
    				speed: 0.3,
    			});
		    }
        });
    }

    var parentBody = window.parent.document.getElementsByClassName("elementor-editor-wp-page");
    var parentBod = $(parentBody);

    function updatePageSettings(newValue) {
        elementor.saver.update({
            onSuccess: function() {
                elementor.reloadPreview();
                elementor.once( 'preview:loaded', function() {
                    elementor.getPanelView().setPage('page_settings').activateTab('settings');
                    //jQuery(parentBod).find('.elementor-tab-control-settings').addClass('elementor-active');
                    //jQuery(parentBod).find('#elementor-panel-footer-settings').trigger('click');
                } );
            }
        });
    }

    jQuery(window).on('elementor/frontend/init', function () {
        if ( typeof elementor != "undefined" && typeof elementor.settings.page != "undefined") {
            elementor.settings.page.addChangeCallback( 'r_energy_hide_page_header', updatePageSettings );
            elementor.settings.page.addChangeCallback( 'r_energy_hide_page_footer_widgetize', updatePageSettings );
            elementor.settings.page.addChangeCallback( 'r_energy_hide_page_footer', updatePageSettings );
            elementor.settings.page.addChangeCallback( 'r_energy_page_header_type', updatePageSettings );
        }
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-home-slider-one.default', homeSlider1);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-home-slider-two.default', homeSlider1);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-home-slider-three.default', homeSlider1);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-home-slider-one.default', jarallaxElement);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-home-slider-two.default', jarallaxElement);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-home-slider-three.default', jarallaxElement);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-about-us-one-section.default', jarallaxElement);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-product-info-parallax-section.default', jarallaxElement);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-cooperation-slider-section.default', cooperationSlider);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-testimonials-one-section.default', testiPrimary);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-partners-slider-section.default', brandsSlider);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-brands-slider-section.default', brandsSliderTwo);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-cases-cpt-slider-section.default', casesSlider);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-woo-product-slider-section.default', productsSlider);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-instagram-slider-section.default', instagramSlider);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-project-gallery-slider-section.default', projectGallery);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-contact-form-map-section.default', formFocusCorrection);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-contact-form-7.default', formFocusCorrection);
        elementorFrontend.hooks.addAction('frontend/element_ready/r-energy-vertical-tabs-section.default', detailTabs);
    });
})(jQuery);
