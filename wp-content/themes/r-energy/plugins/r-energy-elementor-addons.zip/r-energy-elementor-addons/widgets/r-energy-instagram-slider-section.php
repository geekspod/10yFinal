<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class R_Energy_Instagram_Slider_Section_Widget extends Widget_Base {
    use R_Energy_Helper;
    public function get_name() {
        return 'r-energy-instagram-slider-section';
    }
    public function get_title() {
        return 'Instagram Slider';
    }
    public function get_icon() {
        return 'eicon-slider-push';
    }
    public function get_categories() {
        return [ 'r-energy' ];
    }
    // Registering Controls
    protected function _register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'r_energy_partner_slider_settings',
            [
                'label' => esc_html__('Text', 'r-energy'),
            ]
        );
        $this->add_control( 'subtitle',
            [
                'label' => esc_html__( 'Subtitle', 'r-energy' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Instagram',
                'label_block' => true,
            ]
        );
        $this->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'r-energy' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '<span>#r-energy</span>',
                'label_block' => true,
            ]
        );
        $this->add_control( 'hide_icon',
            [
                'label' => esc_html__( 'Hide Icon', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'r_energy_gallery_image_settings',
            [
                'label' => esc_html__('Gallery Items', 'r-energy'),
            ]
        );
        $repeater = new Repeater();
        $def_image = plugins_url( 'assets/front/img/ig-1.jpg', __DIR__ );
        $repeater->add_control( 'item_image',
            [
                'label' => esc_html__( 'Image', 'r-energy' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => $def_image],
            ]
        );
        $repeater->add_control( 'link',
            [
                'label' => esc_html__( 'Add Link', 'r-energy' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => ''
                ],
                'show_external' => true
            ]
        );
        $this->add_control( 'gallery',
            [
                'label' => esc_html__( 'Items', 'nt-addons' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => 'Image',
                'default' => [
                    [
                        'item_image' => ['url' => $def_image]
                    ],
                    [
                        'item_image' => ['url' => $def_image]
                    ],
                    [
                        'item_image' => ['url' => $def_image]
                    ],
                    [
                        'item_image' => ['url' => $def_image]
                    ],
                    [
                        'item_image' => ['url' => $def_image]
                    ],
                    [
                        'item_image' => ['url' => $def_image]
                    ]
                ]
            ]
        );
        $this->end_controls_section();

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'instagram_slider_options_section',
            [
                'label' => esc_html__( 'Slider Options', 'r-energy' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'adaptiveHeight',
            [
                'label' => esc_html__( 'Adaptive Height', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'infinite',
            [
                'label' => esc_html__( 'Infinite', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 50,
                'max' => 5000,
                'default' => 300,
            ]
        );
        $this->add_control( 'slidesToShow',
            [
                'label' => esc_html__( 'Slides To Show', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 6,
            ]
        );
        $this->add_control( 'slidesToScroll',
            [
                'label' => esc_html__( 'Slides To Scroll', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow1600',
            [
                'label' => esc_html__( 'Slides To Show ( 1600px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 5,
            ]
        );
        $this->add_control( 'slidesToScroll1600',
            [
                'label' => esc_html__( 'Slides To Scroll ( 1600px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow1366',
            [
                'label' => esc_html__( 'Slides To Show ( 1366px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 4,
            ]
        );
        $this->add_control( 'slidesToScroll1366',
            [
                'label' => esc_html__( 'Slides To Scroll ( 1366px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow992',
            [
                'label' => esc_html__( 'Slides To Show ( 992px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 3,
            ]
        );
        $this->add_control( 'slidesToScroll992',
            [
                'label' => esc_html__( 'Slides To Scroll ( 992px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow768',
            [
                'label' => esc_html__( 'Slides To Show ( 768px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToScroll768',
            [
                'label' => esc_html__( 'Slides To Scroll ( 768px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings  = $this->get_settings_for_display();
        $elementid = $this->get_id();

        $autoplay = 'yes' == $settings['autoplay'] ? 'true' : 'false';
        $adaptiveHeight = 'yes' == $settings['adaptiveHeight'] ? 'true' : 'false';
        $infinite = 'yes' == $settings['infinite'] ? 'true' : 'false';
        $dots = 'yes' == $settings['dots'] ? 'true' : 'false';
        $speed = $settings['speed'] ? $settings['speed'] : 300;
        $slidesToShow = $settings['slidesToShow'] ? $settings['slidesToShow'] : 6;
        $slidesToScroll = $settings['slidesToScroll'] ? $settings['slidesToScroll'] : 2;
        $slidesToShow1600 = $settings['slidesToShow1600'] ? $settings['slidesToShow1600'] : 5;
        $slidesToScroll1600 = $settings['slidesToScroll1600'] ? $settings['slidesToScroll1600'] : 2;
        $slidesToShow1366 = $settings['slidesToShow1366'] ? $settings['slidesToShow1366'] : 4;
        $slidesToScroll1366 = $settings['slidesToScroll1366'] ? $settings['slidesToScroll1366'] : 2;
        $slidesToShow992 = $settings['slidesToShow992'] ? $settings['slidesToShow992'] : 3;
        $slidesToScroll992 = $settings['slidesToScroll992'] ? $settings['slidesToScroll992'] : 2;
        $slidesToShow768 = $settings['slidesToShow768'] ? $settings['slidesToShow768'] : 2;
        $slidesToScroll768 = $settings['slidesToScroll768'] ? $settings['slidesToScroll768'] : 2;

        echo '<div class="section instagram no-padding-top">';
            if ( $settings['subtitle'] || $settings['title'] || $settings['hide_icon'] != 'yes' ) {
                echo '<div class="container">';
                    echo '<div class="row align-items-end margin-bottom">';
                        if ( $settings['subtitle'] || $settings['title'] ) {
                            echo '<div class="col-10">';
                                echo '<div class="heading primary-heading">';
                                    if ( $settings['subtitle'] ) {
                                        echo '<h3 class="title">'.$settings['subtitle'].'</h3>';
                                    }
                                    if ( $settings['title'] ) {
                                        echo '<h5 class="subtitle">'.$settings['title'].'</h5>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        }
                        if ( $settings['hide_icon'] != 'yes' ) {
                            echo '<div class="col-2">';
                                echo '<div class="icon-holder"><i class="fa fa-instagram" aria-hidden="true"></i></div>';
                            echo '</div>';
                        }
                    echo '</div>';
                echo '</div>';
            }
            echo '<div class="instagram-slider-holder">';
                echo '<div class="instagram-slider" data-slider-settings=\'{"autoplay":'.$autoplay.',"adaptiveHeight":'.$adaptiveHeight.',"infinite":'.$infinite.',"dots":'.$dots.',"speed":'.$speed.',"slidesToShow":'.$slidesToShow.',"slidesToScroll":'.$slidesToScroll.',"slidesToShow1600":'.$slidesToShow1600.',"slidesToScroll1600":'.$slidesToScroll1600.',"slidesToShow1366":'.$slidesToShow1366.',"slidesToScroll1366":'.$slidesToScroll1366.',"slidesToShow992":'.$slidesToShow992.',"slidesToScroll992":'.$slidesToScroll992.',"slidesToShow768":'.$slidesToShow768.',"slidesToScroll768":'.$slidesToScroll768.'}\'>';
                    foreach ( $settings['gallery'] as $item ) {
                        $imagealt = esc_attr(get_post_meta($item['item_image']['id'], '_wp_attachment_image_alt', true));
                        $imagealt = $imagealt ? $imagealt : basename(get_attached_file($item['item_image']['id']));
                        $target   = $item['link']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $item['link']['nofollow'] ? ' rel="nofollow"' : '';
                        if ( $item['item_image']['url'] ) {
                            if ( $item['link']['url'] ) {
                                echo '<a class="img-holder" href="'.$item['link']['url'].'"'.$target.$nofollow.'><img class="img-bg" src="'.$item['item_image']['url'].'" alt="'.$imagealt.'"/><i class="fa fa-instagram" aria-hidden="true"></i></a>';
                            } else {
                                echo '<div class="img-holder"><img class="img-bg" src="'.$item['item_image']['url'].'" alt="'.$imagealt.'"/><i class="fa fa-instagram" aria-hidden="true"></i></div>';
                            }
                        }
                    }
                echo '</div>';
                echo '<div class="instagram-dots"></div>';
            echo '</div>';
        echo '</div>';
    }
}
