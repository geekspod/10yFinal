<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class R_Energy_Project_Gallery_Slider_Section_Widget extends Widget_Base {
    use R_Energy_Helper;
    public function get_name() {
        return 'r-energy-project-gallery-slider-section';
    }
    public function get_title() {
        return 'Project Gallery Slider';
    }
    public function get_icon() {
        return 'eicon-slider-push';
    }
    public function get_categories() {
        return [ 'r-energy' ];
    }
    // Registering Controls
    protected function _register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'r_energy_partner_slider_settings',
            [
                'label' => esc_html__('Slider Content', 'r-energy'),
            ]
        );
        $this->add_control( 'title',
            [
                'label' => esc_html__( 'Section Title', 'r-energy' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '<span>Project</span> <span>Gallery</span>',
                'label_block' => true
            ]
        );
        $this->add_control( 'gallery',
            [
                'label' => esc_html__( 'Add Images', 'r-energy' ),
                'type' => Controls_Manager::GALLERY,
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'brands_slider_options_section',
            [
                'label' => esc_html__( 'Slider Options', 'r-energy' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'adaptiveHeight',
            [
                'label' => esc_html__( 'Adaptive Height', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'infinite',
            [
                'label' => esc_html__( 'Infinite', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 50,
                'max' => 5000,
                'default' => 300,
            ]
        );
        $this->add_control( 'slidesToShow',
            [
                'label' => esc_html__( 'Slides To Show', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 6,
            ]
        );
        $this->add_control( 'slidesToScroll',
            [
                'label' => esc_html__( 'Slides To Scroll', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow1600',
            [
                'label' => esc_html__( 'Slides To Show ( 1600px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 5,
            ]
        );
        $this->add_control( 'slidesToScroll1600',
            [
                'label' => esc_html__( 'Slides To Scroll ( 1600px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow1366',
            [
                'label' => esc_html__( 'Slides To Show ( 1366px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 4,
            ]
        );
        $this->add_control( 'slidesToScroll1366',
            [
                'label' => esc_html__( 'Slides To Scroll ( 1366px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow992',
            [
                'label' => esc_html__( 'Slides To Show ( 992px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 3,
            ]
        );
        $this->add_control( 'slidesToScroll992',
            [
                'label' => esc_html__( 'Slides To Scroll ( 992px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow768',
            [
                'label' => esc_html__( 'Slides To Show ( 768px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToScroll768',
            [
                'label' => esc_html__( 'Slides To Scroll ( 768px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'project_text_options_section',
            [
                'label' => esc_html__( 'Section Options', 'r-energy' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'title_heading',
            [
                'label' => esc_html__( 'Title Options', 'r-energy' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Typography', 'r-energy' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .primary-heading .title'
            ]
        );
        $this->add_control('title_color',
            [
                'label' => esc_html__( 'Color', 'r-energy' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .primary-heading .subtitle span'=> 'color: {{VALUE}};',
                    '{{WRAPPER}} .primary-heading .subtitle::before'=> 'color: {{VALUE}};'
                ]
            ]
        );
        $this->add_control('title2_color',
            [
                'label' => esc_html__( 'Color 2', 'r-energy' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .primary-heading .subtitle span:last-of-type'=> 'color: {{VALUE}};']
            ]
        );
        $this->add_control( 'background_heading',
            [
                'label' => esc_html__( 'Background Options', 'r-energy' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'project_background',
                'label' => esc_html__( 'Background', 'r-energy' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .project-gallery-section',
                'separator' => 'before'
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
    }

    protected function render() {
        $settings  = $this->get_settings_for_display();
        $elementid = $this->get_id();

        $autoplay = 'yes' == $settings['autoplay'] ? 'true' : 'false';
        $adaptiveHeight = 'yes' == $settings['adaptiveHeight'] ? 'true' : 'false';
        $infinite = 'yes' == $settings['infinite'] ? 'true' : 'false';
        $dots = 'yes' == $settings['dots'] ? 'true' : 'false';
        $speed = $settings['speed'] ? $settings['speed'] : 300;
        $slidesToShow = $settings['slidesToShow'] ? $settings['slidesToShow'] : 6;
        $slidesToScroll = $settings['slidesToScroll'] ? $settings['slidesToScroll'] : 2;
        $slidesToShow1600 = $settings['slidesToShow1600'] ? $settings['slidesToShow1600'] : 5;
        $slidesToScroll1600 = $settings['slidesToScroll1600'] ? $settings['slidesToScroll1600'] : 2;
        $slidesToShow1366 = $settings['slidesToShow1366'] ? $settings['slidesToShow1366'] : 4;
        $slidesToScroll1366 = $settings['slidesToScroll1366'] ? $settings['slidesToScroll1366'] : 2;
        $slidesToShow992 = $settings['slidesToShow992'] ? $settings['slidesToShow992'] : 3;
        $slidesToScroll992 = $settings['slidesToScroll992'] ? $settings['slidesToScroll992'] : 2;
        $slidesToShow768 = $settings['slidesToShow768'] ? $settings['slidesToShow768'] : 2;
        $slidesToScroll768 = $settings['slidesToScroll768'] ? $settings['slidesToScroll768'] : 2;

        echo '<div class="project-gallery-section">';
            if ( $settings['title'] ) {
                echo '<div class="container">';
                    echo '<div class="row">';
                        echo '<div class="col-12">';
                            echo '<div class="heading primary-heading">';
                                echo '<h5 class="subtitle">'.$settings['title'].'</h5>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            }
            echo '<div class="row no-gutters">';
                echo '<div class="col-12">';
                    echo '<div class="project-gallery-holder">';
                        echo '<div class="project-gallery" data-slider-settings=\'{"autoplay":'.$autoplay.',"adaptiveHeight":'.$adaptiveHeight.',"infinite":'.$infinite.',"dots":'.$dots.',"speed":'.$speed.',"slidesToShow":'.$slidesToShow.',"slidesToScroll":'.$slidesToScroll.',"slidesToShow1600":'.$slidesToShow1600.',"slidesToScroll1600":'.$slidesToScroll1600.',"slidesToShow1366":'.$slidesToShow1366.',"slidesToScroll1366":'.$slidesToScroll1366.',"slidesToShow992":'.$slidesToShow992.',"slidesToScroll992":'.$slidesToScroll992.',"slidesToShow768":'.$slidesToShow768.',"slidesToScroll768":'.$slidesToScroll768.'}\'>';
                        foreach ( $settings['gallery'] as $image ) {
                            $imagealt = esc_attr(get_post_meta($image['id'], '_wp_attachment_image_alt', true));
                            $imagealt = $imagealt ? $imagealt : basename ( get_attached_file( $image['id'] ) );
                            echo '<a class="gallery-item" href="' . $image['url'] . '" data-fancybox="project-gallery">';
                                echo '<div class="overlay"></div>';
                                echo '<img class="img-bg" src="' . $image['url'] . '" alt="'.$imagealt.'"/>';
                            echo '</a>';
                        }
                    echo '</div>';
                    echo '<div class="project-gallery-dots"></div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    }
}
