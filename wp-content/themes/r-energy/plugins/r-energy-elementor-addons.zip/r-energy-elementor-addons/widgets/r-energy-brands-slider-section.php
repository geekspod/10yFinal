<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class R_Energy_Brands_Slider_Section_Widget extends Widget_Base {
    use R_Energy_Helper;
    public function get_name() {
        return 'r-energy-brands-slider-section';
    }
    public function get_title() {
        return 'Brands Slider';
    }
    public function get_icon() {
        return 'eicon-slider-push';
    }
    public function get_categories() {
        return [ 'r-energy' ];
    }
    // Registering Controls
    protected function _register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'r_energy_brands_text_settings',
            [
                'label' => esc_html__( 'Text', 'r-energy' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control( 'subtitle',
            [
                'label' => esc_html__( 'Subtitle', 'r-energy' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Partners',
                'label_block' => true,
            ]
        );
        $this->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'r-energy' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '<span>R-Energy</span> <span>Brands</span>',
                'label_block' => true,
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'r_energy_brands_slider_settings',
            [
                'label' => esc_html__('Slider Content', 'r-energy'),
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control( 'item_title',
            [
                'label'          => esc_html__( 'Title', 'r-energy' ),
                'type'           => Controls_Manager::TEXTAREA,
                'default'        => 'Item Title',
                'label_block'    => true,
            ]
        );
        $repeater->add_control( 'item_desc',
            [
                'label'          => esc_html__( 'Description', 'r-energy' ),
                'type'           => Controls_Manager::TEXTAREA,
                'default'        => 'Streamer fish California halibut Pacific saury. Slickhead grunion lake trout. Canthigaster rostrata spikefish',
                'label_block'    => true,
            ]
        );
        $def_img = plugins_url( 'assets/front/img/logo1.svg', __DIR__ );
        $repeater->add_control( 'item_img',
            [
                'label' => esc_html__( 'Brands Image', 'r-energy' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => $def_img],
            ]
        );
        $this->add_control( 'sliders',
            [
                'label' => esc_html__( 'Items', 'nt-addons' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{item_title}}',
                'default' => [
                    [
                        'item_img' => ['url' => $def_img],
                        'item_title' => 'We keep adapting our M.O. to better',
                        'item_desc' => 'Streamer fish California halibut Pacific saury. Slickhead grunion lake trout. Canthigaster rostrata spikefish brown trout',
                    ],
                    [
                        'item_img' => ['url' => $def_img],
                        'item_title' => 'We stand close to every to the span',
                        'item_desc' => 'Streamer fish California halibut Pacific saury. Slickhead grunion lake trout. Canthigaster rostrata spikefish brown trout',
                    ],
                    [
                        'item_img' => ['url' => $def_img],
                        'item_title' => 'We keep adapting our M.O. to better',
                        'item_desc' => 'Streamer fish California halibut Pacific saury. Slickhead grunion lake trout. Canthigaster rostrata spikefish brown trout'
                    ]
                ]
            ]
        );
        $this->end_controls_section();
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'brands_slider_options_section',
            [
                'label' => esc_html__( 'Slider Options', 'r-energy' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'adaptiveHeight',
            [
                'label' => esc_html__( 'Adaptive Height', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'infinite',
            [
                'label' => esc_html__( 'Infinite', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'r-energy' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 50,
                'max' => 5000,
                'default' => 300,
            ]
        );
        $this->add_control( 'slidesToShow',
            [
                'label' => esc_html__( 'Slides To Show', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 3,
            ]
        );
        $this->add_control( 'slidesToShow1200',
            [
                'label' => esc_html__( 'Slides To Show ( 1200px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 2,
            ]
        );
        $this->add_control( 'slidesToShow768',
            [
                'label' => esc_html__( 'Slides To Show ( 768px )', 'r-energy' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 10,
                'default' => 1,
            ]
        );
        $this->end_controls_section();
        /***** END SUBTITLE ******/

        /***** SUBTITLE ******/
        $this->start_controls_section('r_energy_brands_subtitle_styling',
            [
                'label' => esc_html__( 'Subtitle', 'r_energy' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->start_controls_tabs('r_energy_subtitle_brands_tabs');
        $this->start_controls_tab( 'r_energy_subtitle_brands_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='subtitle_brands',$selector='.primary-heading .title');
        $this->end_controls_tab();
        //
        $this->end_controls_tab();
        $this->start_controls_tab( 'r_energy_subtitle_brands_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='subtitle_brands_hover',$selector='.primary-heading .title:hover');
        $this->end_controls_tab();
        $this->end_controls_tabs();
        //
        $this->end_controls_section();
        /***** END SUBTITLE ******/

        /***** TITLE ******/
        $this->start_controls_section('r_energy_brands_title_styling',
            [
                'label' => esc_html__( 'Title', 'r_energy' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->start_controls_tabs('r_energy_title_brands_tabs');
        $this->start_controls_tab( 'r_energy_title_brands_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='title_brands',$selector='.primary-heading .subtitle span');
        $this->end_controls_tab();
        //
        $this->end_controls_tab();
        $this->start_controls_tab( 'r_energy_title_brands_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='title_brands_hover',$selector='.primary-heading .subtitle span:hover');
        $this->end_controls_tab();
        $this->end_controls_tabs();
        //
        $this->end_controls_section();
        /***** END TITLE ******/
        /***** ITEM TITLE ******/
        $this->start_controls_section('r_energy_brands_ititle_styling',
            [
                'label' => esc_html__( 'Item Title', 'r_energy' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->start_controls_tabs('r_energy_ititle_brands_tabs');
        $this->start_controls_tab( 'r_energy_ititle_brands_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='ititle_brands',$selector='.slider-item .title');
        $this->end_controls_tab();
        //
        $this->end_controls_tab();
        $this->start_controls_tab( 'r_energy_ititle_brands_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='ititle_brands_hover',$selector='.slider-item .title:hover');
        $this->end_controls_tab();
        $this->end_controls_tabs();
        //
        $this->end_controls_section();
        /***** END ITEM TITLE ******/
        /***** ITEM Desc ******/
        $this->start_controls_section('r_energy_brands_idesc_styling',
            [
                'label' => esc_html__( 'Item Description', 'r_energy' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->start_controls_tabs('r_energy_idesc_brands_tabs');
        $this->start_controls_tab( 'r_energy_idesc_brands_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='idesc_brands',$selector='.slider-item p');
        $this->end_controls_tab();
        //
        $this->end_controls_tab();
        $this->start_controls_tab( 'r_energy_idesc_brands_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'r_energy' ) ]
        );
        $this->r_energy_style_controls(array('shadow'),$id='idesc_brands_hover',$selector='.slider-item p:hover');
        $this->end_controls_tab();
        $this->end_controls_tabs();
        //
        $this->end_controls_section();
        /***** END ITEM Desc ******/
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'brands_text_options_section',
            [
                'label' => esc_html__( 'Section Options', 'r-energy' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control( 'subtitle_heading',
            [
                'label' => esc_html__( 'Subtitle Options', 'r-energy' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
        $this->add_control('subtitle_color',
            [
                'label' => esc_html__( 'Color', 'r-energy' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .primary-heading .title'=> 'color: {{VALUE}};']
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typo',
                'label' => esc_html__( 'Typography', 'r-energy' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .primary-heading .title'
            ]
        );
        $this->add_control( 'title_heading',
            [
                'label' => esc_html__( 'Title Options', 'r-energy' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Typography', 'r-energy' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .primary-heading .title'
            ]
        );
        $this->add_control('title_color',
            [
                'label' => esc_html__( 'Color', 'r-energy' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .primary-heading .subtitle span'=> 'color: {{VALUE}};',
                    '{{WRAPPER}} .primary-heading .subtitle::before'=> 'color: {{VALUE}};'
                ]
            ]
        );
        $this->add_control('title2_color',
            [
                'label' => esc_html__( 'Color 2', 'r-energy' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .primary-heading .subtitle span:last-of-type'=> 'color: {{VALUE}};']
            ]
        );
        $this->add_control( 'background_heading',
            [
                'label' => esc_html__( 'Background Options', 'r-energy' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'brands_background',
                'label' => esc_html__( 'Background', 'r-energy' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .brands--style-2',
                'separator' => 'before'
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'brands_background2',
                'label' => esc_html__( 'Background', 'r-energy' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .brands--style-2::after',
                'separator' => 'before'
            ]
        );
        $this->add_responsive_control('brands_margin',
            [
                'label'         => esc_html__( 'Margin', 'r-energy' ),
                'type'          => Controls_Manager::DIMENSIONS,
                'size_units'    => [ 'px', 'em', '%' ],
                'selectors'     => ['{{WRAPPER}} .brands--style-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'],
                'default'       => [
                    'top'          => '',
                    'right'        => '',
                    'bottom'       => '',
                    'left'         => '',
                ],
                'separator'     => 'before'
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
    }

    protected function render() {
        $settings  = $this->get_settings_for_display();
        $elementid = $this->get_id();

        $autoplay = 'yes' == $settings['autoplay'] ? 'true' : 'false';
        $adaptiveHeight = 'yes' == $settings['adaptiveHeight'] ? 'true' : 'false';
        $infinite = 'yes' == $settings['infinite'] ? 'true' : 'false';
        $dots = 'yes' == $settings['dots'] ? 'true' : 'false';
        $speed = $settings['speed'] ? $settings['speed'] : 300;
        $slidesToShow = $settings['slidesToShow'] ? $settings['slidesToShow'] : 3;
        $slidesToShow1200 = $settings['slidesToShow1200'] ? $settings['slidesToShow1200'] : 2;
        $slidesToShow768 = $settings['slidesToShow768'] ? $settings['slidesToShow768'] : 1;

        echo '<div class="section brands--style-2">';
            if ( $settings['subtitle'] || $settings['title'] ) {
                echo '<div class="container">';
                    echo '<div class="row">';
                        echo '<div class="col-12">';
                            echo '<div class="heading primary-heading">';
                                if ( $settings['subtitle'] ) {
                                    echo '<h3 class="title">'.$settings['subtitle'].'</h3>';
                                }
                                if ( $settings['title'] ) {
                                    echo '<h5 class="subtitle">'.$settings['title'].'</h5>';
                                }
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            }
            echo '<div class="container">';
                echo '<div class="row">';
                    echo '<div class="col-12">';
                        echo '<div class="items-slider" data-slider-settings=\'{"autoplay":'.$autoplay.',"adaptiveHeight":'.$adaptiveHeight.',"infinite":'.$infinite.',"dots":'.$dots.',"speed":'.$speed.',"slidesToShow":'.$slidesToShow.',"slidesToShow1200":'.$slidesToShow1200.',"slidesToShow768":'.$slidesToShow768.'}\'>';
                            foreach ($settings['sliders'] as $item) {
                                $imagealt  = esc_attr(get_post_meta($item['item_img']['id'], '_wp_attachment_image_alt', true));
                                $imagealt  = $imagealt ? $imagealt : basename ( get_attached_file( $item['item_img']['id'] ) );
                                echo '<div class="slider-item">';
                                    echo '<figure class="brand-item--style-2">';
                                        if ( $item['item_img']['url'] ) {
                                            echo '<div class="img-holder"><img src="'.$item['item_img']['url'].'" alt="'.$imagealt.'"/></div>';
                                        }
                                        if ( $item['item_title'] || $item['item_desc'] ) {
                                            echo '<figcaption>';
                                                if ( $item['item_title'] ) {
                                                    echo '<h4 class="title">'.$item['item_title'].'</h4>';
                                                }
                                                if ( $item['item_desc'] ) {
                                                    echo wpautop($item['item_desc']);
                                                }
                                            echo '</figcaption>';
                                        }
                                    echo '</figure>';
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    }
}
