<section class="login-section">
      <div class="container">
      <div class="row">
      <div class="col-md-12" id="registerrsult">
     <h2>ANTI-SPAM POLICY</h2>
<p ><span >All users of WEPRO INVESTMENT services are notified that the company is fighting spam. If there is sufficient reason to believe that the client has committed actions of this nature, the account of the violator may be temporarily frozen until the circumstances are clarified or may be blocked without the right to restore.</span></p>
<p>This document is subject to changes and additions by company employees at any time. At the same time, WEPRO INVESTMENT assumes no obligation to notify users in advance of such changes</p>
<p>The company’s administration uses all available means to prevent cases of commercial mass mailing. Accordingly, such materials are sent to the client’s mail only if he has previously agreed to receive them.</p>
<p >
  <br>
</p>
<p ><span >Each user is fully responsible for the content of letters received from his personal e-mail. If the level of complaints about mailings from a particular e-mail box exceeds the permissible threshold, the WEPRO INVESTMENT administration at its sole discretion may freeze or permanently block the violator's account on the platform.</span></p>

      </div>
      

      


      </div>
      </div>
   </section>