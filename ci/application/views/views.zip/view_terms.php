
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $page_terms['term_content'] ; ?>
                
            </div>
        </div>
    </div>