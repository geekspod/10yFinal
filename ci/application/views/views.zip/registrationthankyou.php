 
<section class="subscription-cancel">
	<div class="container">
	<div class="subscription-cancel-data">
	<h5>Thank you for your Registration!</h5>
	<p>Kindly check your Email Inbox/Junk for confirmation link </p>
	<a href="<?php echo base_url() ; ?>login"> LOGIN </a> / <a href="<?php echo base_url() ; ?>"> BACK HOME </a>
	</div>
	</div>
</section>