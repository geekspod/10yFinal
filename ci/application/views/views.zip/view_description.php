<?php echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";?>
<h1>Thank you for your valuable time.</h1>




<?php
                $i=0;
                if (!empty($description)){
            	foreach ($description as $row) {
            		$i++;
            		
								
								
								echo '<p>Description is:'.'&nbsp &nbsp &nbsp &nbsp'.$row['name'].'</p>';

							}
            }
            	?>

            		
								
								
<?php			echo '<p>Score is:'.'&nbsp &nbsp &nbsp &nbsp'.$grade.'</p>';?>

						

								
                                </select>
							    </div>
 								</div>
								</div>
								

<?php echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";?>

