<!DOCTYPE html>
<html>

<section class="chose-opt-banner container">
	<div class="inner">
		
		<div class="chef-form">
			<div class="row">
				<div class="col-md-12">
					<a href="<?php echo base_url() ; ?>register/index/employer" class="btn btn-primary btn-lg">Contact Your Employer </a>
				</div>
			</div>
			
		</div>
	</div>
</section>
